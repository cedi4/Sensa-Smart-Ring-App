import { colors } from '@/styles/global';
import { LinearGradient } from 'expo-linear-gradient';
import { Stack } from 'expo-router';

export default function RootLayout() {
  return (
     <LinearGradient colors={colors.gradient} style={{ flex: 1 }}> 
        <Stack
          screenOptions={{
            headerStyle: { backgroundColor: colors.header },
            headerTintColor: '#fff',
            contentStyle: { backgroundColor: 'transparent' }, 
          }}
        >
        <Stack.Screen 
          name='settings_nameChangeScreen'
          options={{ title: 'Change Username' }} 
        />
        <Stack.Screen
            name='deviceConnectionScreen'
            options={{ title: 'Device Connection' }}
          />
        <Stack.Screen
          name='behaviorDetectedScreen'
          options={{ title: 'Behavior Detected' }}
        />
        <Stack.Screen
          name='specificEventScreen'
          options={{ title: 'Specific Event' }}
        />
        <Stack.Screen name='(tabs)' options={{ headerShown: false }} />
      </Stack>
    </LinearGradient>
  );
}