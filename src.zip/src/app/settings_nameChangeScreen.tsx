import { globalStyles } from '@/styles/global';
import { Text, View } from 'react-native';

export default function ChangeUserNameScreen() {
  return (
    <View style={globalStyles.container}>
      <Text style={globalStyles.title}>Change Name</Text>
    </View>
  );
}