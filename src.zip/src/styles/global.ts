import { StyleSheet } from 'react-native';

export const colors = {
  background: '#071B2B',
  header: '#242444',
  surface: '#167D8D',
  primary: '#4fc3f7',
  text: '#ffffff',
  textSecondary: '#ffffff',
  alert: '#ff5252',
  success: '#2e9e4a', 
  muted: '#c3c9c0',
  batteryGreen: '#198900',
  batteryYellow: '#d3e200',
  batteryRed: '#ff0000',
  gradient: ['#E6FFFE', '#F2F0EF'] as const,
};

export const globalStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 50,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.textSecondary,
    marginTop: 30,
    marginBottom: 16,
  },
  empty: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});